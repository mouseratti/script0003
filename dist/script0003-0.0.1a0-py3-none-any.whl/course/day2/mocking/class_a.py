
class A:
    def __init__(self, param1):
        self.param1 = param1

    def get_param1_value(self):
        return self.param1.get_value(self)


