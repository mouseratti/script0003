
def func1(i):

    if i>6: return 6
    return i