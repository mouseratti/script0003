import logging

LOGLEVEL = "DEBUG"
LOG_FORMAT = "%(asctime)s %(name)s:%(levelname)s:: %(message)s"
LOGFILE = "LOGFILE.log"