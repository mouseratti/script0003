"""
Create your own enumerate implementation in this module
https://docs.python.org/3/library/functions.html#enumerate
"""
from typing import (
    Iterable,
    Generator
)
def my_enumerate(i: Iterable, start: int = 0) -> Generator:
    pass
    # type your code here
