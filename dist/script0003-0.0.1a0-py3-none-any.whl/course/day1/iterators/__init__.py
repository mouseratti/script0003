from .fib import gen_fib
from .fib import func_fib
from .enumerator import my_enumerate


