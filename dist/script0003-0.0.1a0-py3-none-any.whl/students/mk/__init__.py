from course.day1.cached import f as F
from course.day1.cached import *
from course.day1.cached import f2
